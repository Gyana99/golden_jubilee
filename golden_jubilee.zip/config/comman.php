<?php
define('APP_URL', env('APP_URL').'/ajax');
define('ROOT_URL', env('APP_URL'));
?>
