<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Contributions List')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <style>
        /* Grid for cards */
        .contribution-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        /* Card style */
        .contribution-card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .contribution-card:hover {
            box-shadow: 0 6px 15px rgba(0,0,0,0.1);
            transform: translateY(-3px);
        }

        .contribution-card h3 {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 6px;
        }

        .contribution-card p {
            font-size: 14px;
            margin: 3px 0;
            color: #555;
        }

        .contribution-card img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            margin-top: 6px;
            transition: transform 0.2s;
        }

        .contribution-card img:hover {
            transform: scale(1.1);
        }

        /* Action buttons area */
        .card-actions {
            background: #f9fafb;
            border-top: 1px solid #eee;
            padding: 8px 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-actions a,
        .card-actions button {
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: color 0.2s;
        }

        .card-actions a {
            color: #2563eb;
            text-decoration: none;
        }

        .card-actions a:hover {
            text-decoration: underline;
        }

        .card-actions button {
            background: none;
            border: none;
            color: #dc2626;
        }

        .card-actions button:hover {
            text-decoration: underline;
        }
    </style>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <!-- Add Button -->
            <a href="<?php echo e(route('contributions.create')); ?>"
               class="mb-6 inline-block bg-blue-600 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700"
               style="background:#24cdcd;">
                ➕ Add Contribution
            </a>

            <!-- Success Message -->
            <?php if(session('success')): ?>
                <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <!-- Cards Grid -->
            <div class="contribution-grid">
                <?php $__empty_1 = true; $__currentLoopData = $contributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="contribution-card">
                        <div class="p-4">
                            <h3>
                                <?php echo e($contribution->alumni->name); ?>

                                <span style="color:#777; font-size:13px;">
                                    (<?php echo e($contribution->alumni->passout_year); ?>)
                                </span>
                            </h3>
                            <p><strong>Amount:</strong> ₹<?php echo e(number_format($contribution->amount, 2)); ?></p>
                            <p><strong>Date:</strong> <?php echo e($contribution->payment_date); ?></p>

                            <div>
                                <strong>Receipt:</strong><br>
                                <?php if($contribution->payment_photo): ?>
                                    <img src="<?php echo e(asset('storage/'.$contribution->payment_photo)); ?>" alt="Receipt">
                                <?php else: ?>
                                    <span style="color:#aaa;">—</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Actions -->
                        <div class="card-actions">
                            <a href="<?php echo e(route('contributions.edit', $contribution->id)); ?>">✏ Edit</a>
                            <form action="<?php echo e(route('contributions.destroy', $contribution->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button onclick="return confirm('Are you sure?')">🗑 Delete</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center p-6 bg-gray-50 border rounded">
                        No contributions found.
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <div class="mt-6">
                <?php echo e($contributions->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\golden_jubilee\resources\views/contributions/index.blade.php ENDPATH**/ ?>