<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Alumni List')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <!-- ✅ Inline CSS: guaranteed horizontal scroll -->
    <style>
        .table-scroll {
            overflow-x: auto;
            width: 100%;
            -webkit-overflow-scrolling: touch; /* smooth on iOS */
            scrollbar-width: thin; /* Firefox */
        }
        /* Force the table to be wider than small screens */
        .table-scroll table {
            min-width: 1100px; /* adjust if you add/remove columns */
        }
        /* Keep cells on one line so columns don't shrink */
        .nowrap td, .nowrap th { white-space: nowrap; }
    </style>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <a href="<?php echo e(route('alumni.create')); ?>"
               class="mb-4 inline-block bg-blue-600 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700"
               style="background:#24cdcd;">
                ➕ Add Alumni
            </a>

            <?php if(session('success')): ?>
                <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white shadow-xl sm:rounded-lg">
                <!-- ✅ Real horizontal scroll wrapper -->
                <div class="table-scroll">
                    <table class="min-w-full border text-sm nowrap">
                        <!-- ✅ Column widths to ensure scroll appears -->
                        <colgroup>
                            <col style="width: 70px;">   <!-- # -->
                            <col style="width: 110px;">  <!-- Photo -->
                            <col style="width: 220px;">  <!-- Name -->
                            <col style="width: 300px;">  <!-- Email -->
                            <col style="width: 180px;">  <!-- Phone -->
                            <col style="width: 160px;">  <!-- Passout Year -->
                            <col style="width: 200px;">  <!-- Actions -->
                        </colgroup>

                        <thead class="bg-gray-200 text-gray-700">
                            <tr>
                                <th class="px-4 py-2 border text-left">#</th>
                                <th class="px-4 py-2 border text-left">Photo</th>
                                <th class="px-4 py-2 border text-left">Name</th>
                                <th class="px-4 py-2 border text-left">Email</th>
                                <th class="px-4 py-2 border text-left">Phone</th>
                                <th class="px-4 py-2 border text-left">Passout Year</th>
                                <th class="px-4 py-2 border text-left">Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $alumni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumnus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-4 py-2 border"><?php echo e($alumnus->id); ?></td>

                                    <td class="px-4 py-2 border text-center align-middle">
                                        <?php if($alumnus->photo): ?>
                                            <div class="w-16 h-16 mx-auto rounded-full overflow-hidden border-2 border-gray-300 shadow">
                                                <img
                                                    src="<?php echo e(asset('storage/alumniphoto/'.$alumnus->photo)); ?>"
                                                    alt="<?php echo e($alumnus->name); ?>"
                                                    class="w-16 h-16 object-cover object-center"
                                                >
                                            </div>
                                        <?php else: ?>
                                            <div class="w-16 h-16 flex items-center justify-center bg-gray-200 text-gray-500 rounded-full mx-auto shadow border-2 border-gray-300">
                                                <span class="text-[10px] font-medium">No Photo</span>
                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    <td class="px-4 py-2 border font-medium"><?php echo e($alumnus->name); ?></td>
                                    <td class="px-4 py-2 border"><?php echo e($alumnus->email); ?></td>
                                    <td class="px-4 py-2 border"><?php echo e($alumnus->phone); ?></td>
                                    <td class="px-4 py-2 border"><?php echo e($alumnus->passout_year); ?></td>

                                    <td class="px-4 py-2 border">
                                        <a href="<?php echo e(route('alumni.edit', $alumnus->id)); ?>" class="text-blue-600 hover:underline">✏ Edit</a>
                                        <span class="mx-1 text-gray-400">|</span>
                                        <form action="<?php echo e(route('alumni.destroy', $alumnus->id)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button onclick="return confirm('Are you sure?')" class="text-red-600 hover:underline">🗑 Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center p-4">No alumni found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="p-4">
                    <?php echo e($alumni->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\golden_jubilee\resources\views/alumni/index.blade.php ENDPATH**/ ?>