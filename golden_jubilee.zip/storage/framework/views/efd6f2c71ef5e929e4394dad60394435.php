<footer class="bg-dark text-light py-4">
    <div class="container text-center">
        <p class="mb-1">&copy; <?php echo e(date('Y')); ?> U.G. ବିଦ୍ୟାପୀଠ, ନରେନ୍ଦ୍ରପୁର. All rights reserved.</p>
        <div>
            <a href="#" class="text-light me-3"><i class="bi bi-facebook"></i></a>
            <a href="#" class="text-light me-3"><i class="bi bi-twitter"></i></a>
            <a href="#" class="text-light"><i class="bi bi-instagram"></i></a>
        </div>
    </div>
</footer>
<?php /**PATH D:\xampp\htdocs\golden_jubilee\resources\views/website/include/footer.blade.php ENDPATH**/ ?>